<template>
  <div id="app" class="inner-container">
    <!-- navbar -->
    <div class="navbar navbar-expand-lg fixed-top navbar-dark bg-primary">
      <div class="row">
        <div class="col-md-3">
          <!--<router-link to="/" class="navbar-brand">ตรวจสุขภาพทางการเงิน</router-link>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
          </button>-->
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <!--<router-link class="nav-link" to="/blog">แผนออมเงินเพื่อเป้าหมาย</router-link>-->
                <a
                  href="#"
                  class="nav-link"
                  @click.prevent="$router.push({ name: 'FinancialHealthCheck' })"
                >ตรวจสุขภาพทางการเงิน</a>
              </li>
              <li class="nav-item">
                <!--<router-link class="nav-link" to="/blog">แผนออมเงินเพื่อเป้าหมาย</router-link>-->
                <a
                  href="#"
                  class="nav-link"
                  @click.prevent="$router.push({ name: 'SavingPlan' })"
                >แผนออมเงินเพื่อเป้าหมาย</a>
              </li>
              <li class="nav-item">
                <!--<router-link class="nav-link" to="/services">แผนเกษียณอายุ</router-link>-->
                <a
                  href="#"
                  class="nav-link"
                  @click.prevent="$router.push({ name: 'RetrimentPlan' })"
                >แผนเกษียณอายุ</a>
              </li>
              <li class="nav-item">
                <!--<router-link class="nav-link" to="/contact">แผนประหยัดภาษี</router-link>-->
                <a
                  href="#"
                  class="nav-link"
                  @click.prevent="$router.push({ name: 'TaxSavingPlan' })"
                >แผนประหยัดภาษี</a>
              </li>
              <li class="nav-item">
                <!--<router-link class="nav-link" to="/contact">แผนประหยัดภาษี</router-link>-->
                <a
                  href="#"
                  class="nav-link"
                  @click.prevent="$router.push({ name: 'HomeLoanPlan' })"
                >แผนคำนวณยอดผ่อนชำระสินเชื่อบ้าน</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-9">
          <transition name="moveInUp">
            <router-view/>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
  mounted: function() {}
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 132px;
}

.moveInUp-enter-active {
  animation: fadeIn 2s ease-in;
}

@keyframes fadeIn {
  0% {
    opacity: 0;
  }

  50% {
    opacity: 0.5;
  }

  100% {
    opacity: 1;
  }
}

.moveInUp-leave-active {
  animation: moveInUp 0.3s ease-in;
}

@keyframes moveInUp {
  0% {
    transform: translateY(0);
  }

  100% {
    transform: translateY(-400px);
  }
}

.fincal-quick-plan-slider {
  overflow: hidden;
  margin: 10px;
  height: 252px;
}

.nav-item {
  height: 90px;
  border: 1px solid #ddd;
  border-radius: 10px;
  margin-bottom: 20px;
}

.nav-link {
  line-height: 89px;
  cursor: pointer;
  cursor: hand;
}
</style>
