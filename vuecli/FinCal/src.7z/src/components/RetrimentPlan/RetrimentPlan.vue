﻿<template>
  <div class="Retirement">
    <vue-form :state="formstate" @submit.prevent="this.onSubmit" class="general-form">
      <div class="row">
        <div class="col-centered col-md-10">
          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>อายุของคุณ</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
                <input
                  name="MyAge"
                  v-model.lazy="model.MyAge"
                  type="number"
                  required
                  min="0"
                  max="100"
                  onKeyPress="if(this.value.length==3) return false;"
                >
              </div>
            </div>

            <field-messages
              name="MyAge"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>อายุตอนเกษียณ</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input
                  name="Retire"
                  v-model.lazy="model.Retire"
                  type="number"
                  required
                  min="0"
                  max="100"
                  onKeyPress="if(this.value.length==3) return false;"
                >
              </div>
            </div>

            <field-messages
              name="Retire"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>อยู่จนถึงอายุ</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
                <input
                  name="UntilAge"
                  v-model.lazy="model.UntilAge"
                  type="number"
                  required
                  min="0"
                  max="100"
                  onKeyPress="if(this.value.length==3) return false;"
                >
              </div>
            </div>

            <field-messages
              name="UntilAge"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>หลังเกษียณอยากใช้เงินเดือนละ</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input
                  name="MonthlyRetire"
                  v-model.lazy="model.MonthlyRetire"
                  type="number"
                  required
                  min="0"
                  max="99999999999"
                  onKeyPress="if(this.value.length==12) return false;"
                >
              </div>
            </div>

            <field-messages
              name="MonthlyRetire"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>มีเงินออมไว้แล้ว</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input
                  name="CurrentSaving"
                  v-model.lazy="model.CurrentSaving"
                  type="number"
                  required
                  min="0"
                  max="99999999999"
                  onKeyPress="if(this.value.length==12) return false;"
                >
              </div>
            </div>

            <field-messages
              name="CurrentSaving"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>ผลตอบแทนต่อปีที่คาดหวัง (%)</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input
                  name="ExpectReturn"
                  v-model.lazy="model.ExpectReturn"
                  type="number"
                  required
                  min="0"
                  max="100"
                  onKeyPress="if(this.value.length==3) return false;"
                >
              </div>
            </div>

            <field-messages
              name="ExpectReturn"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label class="form-group required-field">
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>ต้องการออมเพิ่มขึ้นปีละ (%)</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input
                  name="MoreSaving"
                  v-model.lazy="model.MoreSaving"
                  type="number"
                  required
                  min="0"
                  max="100"
                  onKeyPress="if(this.value.length==3) return false;"
                >
              </div>
            </div>

            <field-messages
              name="MoreSaving"
              show="$touched || $submitted"
              class="form-control-feedback"
            >
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>
        </div>
      </div>
      <div class="row">
        <div class="pad-section">
          <tabs
            :tabs="tabs"
            :currentTab="currentTab"
            :wrapper-class="'default-tabs'"
            :tab-class="'default-tabs__item'"
            :tab-active-class="'default-tabs__item_active'"
            :line-class="'default-tabs__active-line'"
            @onClick="handleClick"
          />
          <div class="tabs-content">
            <div v-if="currentTab === 'tab1'">
              <p>เงินกองทุนสำรองเลี้ยงชีพ</p>
              <ProvidentFund></ProvidentFund>
            </div>
            <div v-if="currentTab === 'tab2'">
              <p>กองทุน RMF</p>
              <RMFFund></RMFFund>
            </div>
            <div v-if="currentTab === 'tab3'">
              <p>เงินสะสม/เงินก้อนตอนเกษียณ</p>
              <CumulativeMoney></CumulativeMoney>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div>ResultLiquidity :{{ this.FincalResult}}</div>
        <div>{{this.model.HaveChildren}}</div>
        <!-- <div>CurrentExpense :{{ this.model.CurrentExpense}}</div>
        <div>QuickAsset :{{ this.model.QuickAsset}}</div>-->
        <div class="col-md-10 col-centered">
          <div class="result">
            <p>แนะนำให้ออมเงินเดือนละ {{result.MonthlySavings}} บาท</p>
            <p>โดยออมเงินเพิ่มขึ้นปีละ {{result.YearlySavings}} บาท</p>
            <p>เพื่อให้มีเงิน {{result.TotalSavings}}* บาท ในอีก {{result.Years}} ปีข้างหน้า</p>
          </div>
        </div>
        <!-- <button class='btn btn-primary btn-sm btn-block text-center '   v-on:click='AcceptCanCelOrder '  > Shoot</button> -->
        <div class="col-centered col-xs-11 col-sm-8 col-md-10 col-lg-5">
          <button class="btn btn-primary btn-sm btn-block text-cente" type="submit">คำนวณ</button>
        </div>
      </div>
    </vue-form>
  </div>
</template>

<script>
import Tabs from "../Common/VueTabsWithActiveLine.vue";
import ProvidentFund from "./ProvidentFund";
import RMFFund from "./RMFFund";
import CumulativeMoney from "./CumulativeMoney";

const TABS = [
  {
    title: "เงินกองทุนสำรองเลี้ยงชีพ",
    value: "tab1"
  },
  {
    title: "กองทุน RMF",
    value: "tab2"
  },
  {
    title: "เงินสะสม/เงินก้อนตอนเกษียณ",
    value: "tab3"
  }
];

export default {
  data: function() {
    return {
      formstate: {},
      temp: null, //for number
      visible: true, //for number
      model: {
        MyAge: "30",
        Retire: "60",
        UntilAge: "80",
        MonthlyRetire: "20000",
        CurrentSaving: "0",
        ExpectReturn: "3.0",
        MoreSaving: "0.0"
      },
      result: {
        MonthlySavings: 0,
        YearlySavings: 0,
        TotalSavings: 0,
        Years: 0
      },
      tabs: TABS,
      currentTab: "tab1"
    };
  },
  components: {
    Tabs,
    ProvidentFund,
    RMFFund,
    CumulativeMoney
  },
  methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
    }
  }
};
</script>

<style>
.pad-section {
  margin-top: 10px;
  margin-bottom: 10px;
}

.default-tabs {
  position: relative;
  margin: 0 auto;
}

.default-tabs__item {
  display: inline-block;
  margin: 12px 0px;
  font-size: 1rem;
  color: #003fbd;
  letter-spacing: 0.8px;
  text-decoration: none;
  background-color: transparent;
  cursor: pointer;
  transition: all 0.3s;
  padding: 10px;
}

.default-tabs__item_active {
  color: #003fbd;
}

.default-tabs__item:hover {
  color: #003fbd;
}

.default-tabs__item:focus {
  outline: none;
  color: #003fbd;
}

.default-tabs__item:first-child {
  margin-left: 0;
}

.default-tabs__item:last-child {
  margin-right: 0;
}

.default-tabs__active-line {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 2px;
  background-color: #003fbd;
  transition: all 0.3s;
}

.tabs-content {
  margin-top: 30px;
  font-size: 20px;
}
</style>
