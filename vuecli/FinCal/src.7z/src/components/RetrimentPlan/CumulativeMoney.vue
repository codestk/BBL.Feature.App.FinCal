﻿<template>
  <div class="ProvidentFund">
    <div class="row">
      <div class="col-centered col-md-10">
        <validate auto-label=""
                  class="form-group required-field"
                    >
          <div class="fincal-group">
            <div class="col-md-10 fincal-text-left">
              <label>ยอดสะสม ณ ปัจจุบัน</label>
            </div>

            <div class="col-md-10 fincal-text-right">
              <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
              <input name="AccumulatedAmount"
                     v-model.lazy="model.AccumulatedAmount"
                     type="number"
                     required=""
                     min="0"
                     max="9999999999P9"
                     onKeyPress="if(this.value.length==12) return false;">
              </div>
          </div>

          <field-messages name="AccumulatedAmount"
                          show="$touched || $submitted"
                          class="form-control-feedback">
            <div slot="required">Name is a required field</div>
            <div slot="min">min</div>
            <div slot="max">max</div>
          </field-messages>
        </validate>

        <validate auto-label=""
                   class="form-group required-field"
                     >
          <div class="fincal-group">
            <div class="col-md-10 fincal-text-left">
              <label>ผลตอบแทนต่อปีที่คาดหวัง (%)</label>
            </div>

            <div class="col-md-10 fincal-text-right">
              <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
              <input name="YearlyReturn"
                     v-model.lazy="model.YearlyReturn"
                     type="number"
                     required=""
                     min="0"
                     max="100"
                     onKeyPress="if(this.value.length==3) return false;">
              </div>
          </div>

          <field-messages name="YearlyReturn"
                          show="$touched || $submitted"
                          class="form-control-feedback">
            <div slot="required">Name is a required field</div>
            <div slot="min">min</div>
            <div slot="max">max</div>
          </field-messages>
        </validate>

        <validate auto-label=""
                   class="form-group required-field"
                    >
          <div class="fincal-group">
            <div class="col-md-10 fincal-text-left">
              <label>เงินก้อนที่คาดว่าจะได้รับครั้งเดียว ณ วันเกษียณ</label>
            </div>

            <div class="col-md-10 fincal-text-right">
              <input name="MoneyRetire"
                     v-model.lazy="model.MoneyRetire"
                     type="number"
                     required=""
                     min="0"
                     max="99999999999"
                     onKeyPress="if(this.value.length==12) return false;">
              </div>
          </div>

          <field-messages name="MoneyRetire"
                          show="$touched || $submitted"
                          class="form-control-feedback">
            <div slot="required">Name is a required field</div>
            <div slot="min">min</div>
            <div slot="max">max</div>
          </field-messages>
        </validate>
      </div>
    </div>

    <!-- <button class='btn btn-primary btn-sm btn-block text-center '   v-on:click='AcceptCanCelOrder '  > Shoot</button> -->
    <div class="row">
      <div class="col-centered col-xs-11 col-sm-8 col-md-10 col-lg-5">
        <button class="btn btn-primary btn-sm btn-block text-cente" type="submit">คำนวณ</button>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
  name: "ProvidentFund",
  data: function () {
  return {
  formstate: {},
  temp: null, //for number
  visible: true, //for number
  model: {
  AccumulatedAmount: "500000",
  YearlyReturn: "0",
  MoneyRetire: "0",
  TotalDebt: "0"
  },
  result:{
  MonthlySavings:0,
  YearlySavings:0,
  TotalSavings:0,
  Years:0
  }
  }
  },
  fieldClassName: function (field) {
  if (!field) {
  return "";
  }
  if ((field.$touched || field.$submitted) && field.$valid) {
  return "has-success";
  }
  if ((field.$touched || field.$submitted) && field.$invalid) {
  return "has-danger";
  }
  },
  onSubmit: function () {
  if (this.formstate.$invalid) {
  // alert user and exit early
  return;
  }
  // otherwise submit form
  this.calculator();
  },

  calculator: function () {
  }
  };
</script>

<!-- Add 'scoped' attribute to limit CSS to this component only -->
<style scoped="">
  .result{
  border:1px solid #bbb;
  }
</style>
