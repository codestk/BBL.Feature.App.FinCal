﻿<template>
  <div class="house">
    <vue-form :state="formstate" @submit.prevent="this.onSubmit" class="general-form">
      <div class="row">
        <div class="col-centered col-md-10">
          <validate auto-label=""
                    class="form-group required-field"
                    >
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>ยอดเงินที่ต้องการ</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
                <input name="TotalAmount"
                       v-model.lazy="model.TotalAmount"
                       type="number"
                       required=""
                       min="0"
                       max="99999999999"
                       onKeyPress="if(this.value.length==12) return false;">
                </div>
            </div>

            <field-messages name="TotalAmount"
                            show="$touched || $submitted"
                            class="form-control-feedback">
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label=""
                    class="form-group required-field"
                    >
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>จำนวนปีที่จะออม</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input name="Years"
                       v-model.lazy="model.Years"
                       type="number"
                       required=""
                       min="0"
                       max="120"
                       onKeyPress="if(this.value.length==3) return false;">
                </div>
            </div>

            <field-messages name="Years"
                            show="$touched || $submitted"
                            class="form-control-feedback">
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label=""
                     class="form-group required-field"
                     >
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>มีเงินออมไว้แล้ว</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <!-- <input type="text" name="name" class="form-control" required v-model.lazy="model.CurrentAge"> -->
                <input name="CurrentAmount"
                       v-model.lazy="model.CurrentAmount"
                       type="number"
                       required=""
                       min="0"
                       max="99999999999"
                       onKeyPress="if(this.value.length==12) return false;">
                </div>
            </div>

            <field-messages name="CurrentAmount"
                            show="$touched || $submitted"
                            class="form-control-feedback">
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label=""
                    class="form-group required-field"
                    >
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>ผลตอบแทนต่อปีที่คาดหวัง (%)</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input name="ExpectReturn"
                       v-model.lazy="model.ExpectReturn"
                       type="number"
                       required=""
                       min="0"
                       max="100"
                       onKeyPress="if(this.value.length==3) return false;">
                </div>
            </div>

            <field-messages name="ExpectReturn"
                            show="$touched || $submitted"
                            class="form-control-feedback">
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>

          <validate auto-label=""
                    class="form-group required-field"
                    >
            <div class="fincal-group">
              <div class="col-md-10 fincal-text-left">
                <label>ต้องการออมเพิ่มขึ้นปีละ (%)</label>
              </div>

              <div class="col-md-10 fincal-text-right">
                <input name="MoreSaving"
                       v-model.lazy="model.MoreSaving"
                       type="number"
                       required=""
                       min="0"
                       max="100"
                       onKeyPress="if(this.value.length==3) return false;">
                </div>
            </div>

            <field-messages name="MoreSaving"
                            show="$touched || $submitted"
                            class="form-control-feedback">
              <div slot="required">Name is a required field</div>
              <div slot="min">min</div>
              <div slot="max">max</div>
            </field-messages>
          </validate>
        </div>
      </div>     

      <!-- <button class='btn btn-primary btn-sm btn-block text-center '   v-on:click='AcceptCanCelOrder '  > Shoot</button> -->
      <div class="row">
        <div class="col-centered col-xs-11 col-sm-8 col-md-10 col-lg-5">
          <button class="btn btn-primary btn-sm btn-block text-cente" type="submit">คำนวณ</button>
        </div>
      </div>
    </vue-form>
    <div>ResultLiquidity :{{ this.FincalResult}}</div>
    <div>{{this.model.HaveChildren}}</div>
    <!-- <div>CurrentExpense :{{ this.model.CurrentExpense}}</div>
        <div>QuickAsset :{{ this.model.QuickAsset}}</div>-->
    <div class="col-md-10 col-centered">
      <div class="result">
        <p>แนะนำให้ออมเงินเดือนละ {{result.MonthlySavings}} บาท</p>
        <p>โดยออมเงินเพิ่มขึ้นปีละ {{result.YearlySavings}} บาท</p>
        <p>เพื่อให้มีเงิน {{result.TotalSavings}}* บาท ในอีก {{result.Years}} ปีข้างหน้า</p>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
  name: "BuyHouse",
  data: function () {
  return {
  formstate: {},
  temp: null, //for number
  visible: true, //for number
  model: {
  TotalAmount: "500000",
  Years: "5",
  CurrentAmount: "0",
  ExpectReturn: "0.5",
  MoreSaving: "0",
  TotalDebt: "0"
  },
  result:{
  MonthlySavings:0,
  YearlySavings:0,
  TotalSavings:0,
  Years:0
  }
  }
  },
  fieldClassName: function (field) {
  if (!field) {
  return "";
  }
  if ((field.$touched || field.$submitted) && field.$valid) {
  return "has-success";
  }
  if ((field.$touched || field.$submitted) && field.$invalid) {
  return "has-danger";
  }
  },
  onSubmit: function () {
  if (this.formstate.$invalid) {
  // alert user and exit early
  return;
  }
  // otherwise submit form
  this.calculator();
  },

  calculator: function () {
  }
  };
</script>

<!-- Add 'scoped' attribute to limit CSS to this component only -->
<style scoped="">
.result{
border:1px solid #bbb;
}
</style>
